BOT_TOKEN = "1816198459:AAEG2c-RD1cTZCJqCW9YcTUf13oYIRJ8vz8"
APP_URL = "https://sidrabot.herokuapp.com/" + BOT_TOKEN
